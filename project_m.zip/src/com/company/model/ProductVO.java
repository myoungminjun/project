package com.company.model;

public class ProductVO {
	private String pronum;
	private String proname;
	private int proprice;
	private int procnt;
	private String proimg;
	public String getPronum() {
		return pronum;
	}
	public void setPronum(String pronum) {
		this.pronum = pronum;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public int getProprice() {
		return proprice;
	}
	public void setProprice(int proprice) {
		this.proprice = proprice;
	}
	public int getProcnt() {
		return procnt;
	}
	public void setProcnt(int procnt) {
		this.procnt = procnt;
	}
	public String getProimg() {
		return proimg;
	}
	public void setProimg(String proimg) {
		this.proimg = proimg;
	}
}
