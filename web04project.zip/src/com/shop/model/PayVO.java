package com.shop.model;

public class PayVO {
	   private int zipcode;
	   private String add1;
	   private String add2;
	   private String email;
	   private String contact;
	   private int paytype;
	   private int creditnum;
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getPaytype() {
		return paytype;
	}
	public void setPaytype(int paytype) {
		this.paytype = paytype;
	}
	public int getCreditnum() {
		return creditnum;
	}
	public void setCreditnum(int creditnum) {
		this.creditnum = creditnum;
	}
}
