package com.shop.model;

public class PayVO {
	private int paycode;
	private int scode;
	private String goodsname;
	private String userid;
	private int sprice;
	private int scnt;
	private String contact;
	private int paytype;
	private int creditnum;
	public int getPaycode() {
		return paycode;
	}
	public void setPaycode(int paycode) {
		this.paycode = paycode;
	}
	public int getScode() {
		return scode;
	}
	public void setScode(int scode) {
		this.scode = scode;
	}
	public String getGoodsname() {
		return goodsname;
	}
	public void setGoodsname(String goodsname) {
		this.goodsname = goodsname;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getSprice() {
		return sprice;
	}
	public void setSprice(int sprice) {
		this.sprice = sprice;
	}
	public int getScnt() {
		return scnt;
	}
	public void setScnt(int scnt) {
		this.scnt = scnt;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getPaytype() {
		return paytype;
	}
	public void setPaytype(int paytype) {
		this.paytype = paytype;
	}
	public int getCreditnum() {
		return creditnum;
	}
	public void setCreditnum(int creditnum) {
		this.creditnum = creditnum;
	}
	
}
