package com.shop.model;

public class CustomVO {
	private String cusid;
	private String cuspw;
	private String cusname;
	private String custel;
	private int cuszipcode;
	private String add1;
	private String add2;
	public String getCusid() {
		return cusid;
	}
	public void setCusid(String cusid) {
		this.cusid = cusid;
	}
	public String getCuspw() {
		return cuspw;
	}
	public void setCuspw(String cuspw) {
		this.cuspw = cuspw;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public String getCustel() {
		return custel;
	}
	public void setCustel(String custel) {
		this.custel = custel;
	}
	public int getCuszipcode() {
		return cuszipcode;
	}
	public void setCuszipcode(int cuszipcode) {
		this.cuszipcode = cuszipcode;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	}


