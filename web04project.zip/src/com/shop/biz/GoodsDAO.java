package com.shop.biz;

import java.sql.*;
import java.util.ArrayList;

import com.shop.model.DBConn;
import com.shop.model.GoodsVO;

//Inform테이블에 접근하여 데이터 처리요청되어 온 일을 모두 한 곳에서 처리하기 위한 모듈 =>배치 프로그래밍
public class GoodsDAO {
	private Connection con = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	//공지사항 리스트를 데이터베이스에 접근하여 가져와서 VO에 담은 후 controller에 리턴해주는 역할의 메서드
	public ArrayList<GoodsVO> getGoodsList(){
		ArrayList<GoodsVO> goodsList = null;
		try {
			con = DBConn.getConnection();
			String sql="select*from goods order by gcode desc";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			goodsList = new ArrayList<GoodsVO>();
			while(rs.next()) {
				//데이터베이스 테이블에서 반환된 결과를 각 컬럼별로 지역변수에 담기 
				
				String gcode = rs.getString("gcode");
				String gname = rs.getString("gname");
				int gprice = rs.getInt("gprice");
				int gcnt = rs.getInt("gcnt");
				String gimg = rs.getString("gimg");
				
				//각 지역변수에 담긴 필드값을 VO에 던져주기
				GoodsVO goods = new GoodsVO();
				goods.setGcode(gcode);
				goods.setGname(gname);
				goods.setGprice(gprice);
				goods.setGcnt(gcnt);
				goods.setGimg(gimg);
				
				//VO에 담긴 데이터를 리스트에 담기
				goodsList.add(goods);
			}
	}catch(ClassNotFoundException e){
		System.out.println("드라이버 로딩이 되지 않습니다");
		e.printStackTrace();
	}catch(SQLException e){
		System.out.println("SQL구문 또는 열 이름,변수명 등이 서로 맞지 않습니다.");
		e.printStackTrace();
	}catch(Exception e){
		e.printStackTrace();
	}finally {
		DBConn.close(rs, stmt, con);
	}
		//VO의 값을 리스트에 담은 결과를 반환
		return goodsList;
	}
	public GoodsVO getGoods(GoodsVO vo) {
		GoodsVO goods = null;
		try {
			//읽기전에 조회수 추가
			con = DBConn.getConnection();
			String sql = "select * from goods where gcode = ?";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, vo.getGcode());
			rs = stmt.executeQuery();
			if(rs.next()) {
				goods = new GoodsVO();
				goods.setGcode(rs.getString("gcode"));
				goods.setGname(rs.getString("gname"));
				goods.setGprice(rs.getInt("gprice"));
				goods.setGcnt(rs.getInt("gcnt"));
				goods.setGimg(rs.getString("gimg"));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBConn.close(rs, stmt, con);
		}
		return goods;
	}

	public int addGoods(GoodsVO vo) {
		int cnt =0;
		int data;
		String num2 = "";
		try {
			con = DBConn.getConnection();
			String sql = "insert into goods values (Goods_gcode.NEXTVAL,?,?,?,?)";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, vo.getGname());
			stmt.setInt(2, vo.getGprice());
			stmt.setInt(3, vo.getGcnt());
			stmt.setString(4, vo.getGimg());
			cnt = stmt.executeUpdate();
		
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBConn.close(stmt, con);
		}
		return cnt;
	}
}
